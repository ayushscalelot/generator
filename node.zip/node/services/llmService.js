// services/llmService.js

const axios = require('axios');

const CLOUDFLARE_ACCOUNT_ID = process.env.CLOUDFLARE_ACCOUNT_ID;
const CLOUDFLARE_AUTH_TOKEN = process.env.CLOUDFLARE_AUTH_TOKEN;

// Model to use
const MODEL_NAME = '@cf/meta/llama-3.1-8b-instruct-awq';

const CLOUDFLARE_API_URL = `https://api.cloudflare.com/client/v4/accounts/${CLOUDFLARE_ACCOUNT_ID}/ai/run/${MODEL_NAME}`;

/**
 * Sends a prompt to the Cloudflare LLM and returns the generated text.
 * @param {string} prompt - The user input or system instruction.
 * @returns {Promise<string>} - The AI-generated result.
 */
async function generateFromPrompt(prompt) {
  try {
    const response = await axios.post(
      CLOUDFLARE_API_URL,
      {
        messages: [
          { role: 'system', content: 'You are a helpful assistant.' },
          { role: 'user', content: prompt }
        ]
      },
      {
        headers: {
          Authorization: `Bearer ${CLOUDFLARE_AUTH_TOKEN}`,
          'Content-Type': 'application/json'
        }
      }
    );

    const result = response.data.result;

    if (!result || typeof result.response !== 'string') {
      throw new Error('Invalid LLM response format');
    }

    return result.response.trim();
  } catch (error) {
    console.error('Cloudflare LLM API error:', error.response?.data || error.message);
    throw new Error('LLM service failed');
  }
}

module.exports = {
  generateFromPrompt
};
