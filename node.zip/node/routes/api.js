// routes/api.js

const express = require('express');
const router = express.Router();

// Controllers
const socialController = require('../controllers/socialController');
const seoController = require('../controllers/seoController');
const dashboardController = require('../controllers/dashboardController');

// ---------- Social Module Routes ----------
router.post('/social/content', socialController.generateContentSuggestions);

// ---------- SEO Module Routes ----------
router.post('/seo/keywords', seoController.generateKeywordIdeas);
router.post('/seo/meta', seoController.generateMetaDescriptions);

// ---------- Dashboard Routes ----------
router.post('/dashboard/summary', dashboardController.generateClientSummary);

module.exports = router;
