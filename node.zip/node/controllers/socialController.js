// controllers/socialController.js

const ejs = require('ejs');
const path = require('path');
const { generateFromPrompt } = require('../services/llmService');
const { formatAIResponse } = require('./formatter');

// --- Generate Social Content Suggestions ---
exports.generateContentSuggestions = async (req, res) => {
  try {
    const { campaignName, audience, goals, tone } = req.body;

    if (!campaignName || !audience || !goals) {
      return res.status(400).json({ error: 'Missing required fields: campaignName, audience, goals' });
    }

    const prompt = await ejs.renderFile(
      path.join(__dirname, '../prompts/socialContent.ejs'),
      { campaignName, audience, goals, tone: tone || 'neutral' }
    );

    const aiResponse = await generateFromPrompt(prompt);

    const formatted = formatAIResponse(aiResponse);
    console.log('AI Response:', formatted.text);

    // Return structured response
    res.json({ summary: formatted });

  } catch (error) {
    console.error('Social content suggestion error:', error);
    res.status(500).json({ error: 'Failed to generate content suggestions' });
  }
};
