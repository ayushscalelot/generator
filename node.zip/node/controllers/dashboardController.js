// controllers/dashboardController.js

const ejs = require('ejs');
const path = require('path');
const { generateFromPrompt } = require('../services/llmService');
const { formatAIResponse } = require('./formatter');

exports.generateClientSummary = async (req, res) => {
  try {
    const { clientName, campaigns, metrics } = req.body;

    if (!clientName || !campaigns || !metrics) {
      return res.status(400).json({ error: 'Missing required data (clientName, campaigns, metrics)' });
    }

    // Render the prompt from an EJS template
    const prompt = await ejs.renderFile(
      path.join(__dirname, '../prompts/clientSummary.ejs'),
      { clientName, campaigns, metrics }
    );

    // Send prompt to LLM
    const aiResponse = await generateFromPrompt(prompt);

    const formatted = formatAIResponse(aiResponse);
    console.log('AI Response:', formatted.text);

    // Return structured response
    res.json({ summary: formatted });

  } catch (error) {
    console.error('Dashboard summary error:', error);
    res.status(500).json({ error: 'Failed to generate dashboard summary' });
  }
};
