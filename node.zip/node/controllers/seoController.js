// controllers/seoController.js

const ejs = require('ejs');
const path = require('path');
const { generateFromPrompt } = require('../services/llmService');
const { formatAIResponse } = require('./formatter');

// --- Generate Keyword Ideas ---
exports.generateKeywordIdeas = async (req, res) => {
  try {
    const { title, description } = req.body;

    if (!title || !description) {
      return res.status(400).json({ error: 'Missing required fields: title, description' });
    }

    const prompt = await ejs.renderFile(
      path.join(__dirname, '../prompts/keywordIdeas.ejs'),
      { title, description }
    );

    const aiResponse = await generateFromPrompt(prompt);

    const formatted = formatAIResponse(aiResponse);
    console.log('AI Response:', formatted.text);

    // Return structured response
    res.json({ summary: formatted });

  } catch (error) {
    console.error('Keyword generation error:', error);
    res.status(500).json({ error: 'Failed to generate keywords' });
  }
};

// --- Generate Meta Descriptions ---
exports.generateMetaDescriptions = async (req, res) => {
  try {
    const { title, summary } = req.body;

    if (!title || !summary) {
      return res.status(400).json({ error: 'Missing required fields: title, summary' });
    }

    const prompt = await ejs.renderFile(
      path.join(__dirname, '../prompts/metaDescription.ejs'),
      { title, summary }
    );

    const aiResponse = await generateFromPrompt(prompt);

    const formatted = formatAIResponse(aiResponse);
    console.log('AI Response:', formatted.text);

    // Return structured response
    res.json({ summary: formatted });

  } catch (error) {
    console.error('Meta description error:', error);
    res.status(500).json({ error: 'Failed to generate meta description' });
  }
};
