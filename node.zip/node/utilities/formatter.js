// formatter.js

/**
 * Formats the raw AI response from Cloudflare Worker AI API
 * @param {object} apiResponse - The full response object from Cloudflare API
 * @returns {object} formatted output with text and token usage info
 */
function formatAIResponse(apiResponse) {
  if (!apiResponse || !apiResponse.success) {
    throw new Error('Invalid or unsuccessful API response');
  }

  const { result } = apiResponse;
  if (!result || !result.response) {
    throw new Error('No response found in API result');
  }

  // Extract the AI-generated text
  const text = result.response;

  // Optionally, include token usage info if you want
  const usage = result.usage || {};

  return {
    text: text.trim(), // clean up whitespace
    usage
  };
}

module.exports = { formatAIResponse };
