// Basic model structure
module.exports = {
  name: 'User',
  role: 'admin'
};
