// app.js

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');

const apiRoutes = require('./routes/api');

const app = express();

// Middleware
app.use(cors());
app.use(morgan('dev'));
app.use(express.json());

// Routes
app.use('/ai', apiRoutes);

// Default route
app.get('/', (req, res) => {
  res.send({
    status: 'AI Service Running',
    version: '1.0.0',
    uptime: process.uptime().toFixed(2) + 's'
  });
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!', detail: err.message });
});

// Start the server
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`🚀 AI Service running on http://localhost:${PORT}`);
});
